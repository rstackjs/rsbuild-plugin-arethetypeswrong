export function foo(): number;
